history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl  set-hostname TPServer 
echo "127.0.1.1     TPServer >> /etc/hosts
hostname
echo "127.0.1.1     TPServer" >> /etc/hosts 
hostname
reboot
nano /etc/network/interfaces
nano /etc/network/interfaces
echo "source /etc/network/interfaces.d/*" > /etc/network/interfaces
echo "auto lo" >> /etc/network/interfaces
echo "iface lo inet loopback" >> /etc/network/interfaces
echo "auto enp0s3" >> /etc/network/interfaces
echo "iface enp0s3 inet static" >> /etc/network/interfaces
echo "address 192.168.100.50" >> /etc/network/interfaces
echo "netmask 255.255.255.0" >> /etc/network/interfaces
echo "gateway 192.168.100.1" >> /etc/network/interfaces 
systemctl restart networking
ping -c 4 google.com
apt update 
echo "deb http://deb.debian.org/debian/ bookworm main" > /etc/apt/sources.list 
echo "deb-src http://deb.debian.org/debian/ bookworm main" >> /etc/apt/sources.list
echo "deb http:// security.debian.org/debian-security bookworm-security main" >> /etc/apt//sources.list
echo "deb-src http://security.debian.org/debian-security bookworm-security main" >> /etc/apt/sources.list
echo "deb http://deb.debian.org/debian/ bookworm-updates main" >> /etc/apt/sources.list
echo "deb-src http://deb.debian.org/debian/ bookworm-updates main" >> /etc/apt/sources.list
apt update
apt install nano openssh-server -y
nano /etc/apt/sources.list
apt update
 apt full-upgrade -y
reboot
