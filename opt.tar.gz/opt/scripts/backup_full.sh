#!/bin/bash

if [ "$1" == "-help" ]; then
    echo "Uso: $0 [origen] [destino]"
    exit 0
fi


ORIGEN=$1

DESTINO=$2

if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then
    echo "Error: Faltan argumentos"
    exit 1
fi



if [ ! -d "$ORIGEN" ] || [ ! -d "$DESTINO" ]; then
    echo "Error: Directorios no válidos"
    exit 1
fi


FECHA=$(date +%Y%m%d)

NOMBRE=$(basename "$ORIGEN")

tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN" 


 
