#!/bin/bash

# Validar opcion de ayuda
if [ "$1" == "-help" ]; then
    echo "Uso": ./backup_full.sh [ORIGEN] [DESTINO]"
    echo "Ejemplo: .backup_full.sh /var/log /backup_dir"
    exit 0
fi


# Validar que se pasen exactamente 2 argumentos
if [ $# -ne 2 ]; then 
    echo "Error: Se requieren 2 argumentos. Use -help para ayuda."
    exit 1 
fi

ORIGEN=$1
DESTINO=$2

# Validar que origen  y destino  existan 
if [ ! -d "$ORIGEN" ]; then
    echo "Error: El origen $ORIGEN no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El destino $DESTINO no existe."
    exit 1
fi

# Obtener fecha y armar el nombre del archivo
FECHA=$(date +%Y%m%d)
NOMBRE_CARPETA=$(basename "$ORIGEN")
ARCHIVO="$DESTINO/${NOMBRE_CARPETA}_bkp_${FECHA}.tar.gz"

#Ejecutar el backup
tar -czf "$ARCHIVO" "$ORIGEN" 2>/dev/null

echo "Backup completadocon exito: $ARCHIVO:  
    
